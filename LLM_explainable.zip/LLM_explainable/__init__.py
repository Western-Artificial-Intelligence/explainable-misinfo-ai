"""
LLM_explainable: verification-first misinformation pipeline.

Public API:
- run_claim: end-to-end pipeline (Step 0→5)
- schemas: typed I/O contracts
- config: env-driven config loader
"""

from .pipeline import run_claim
from .config import AppConfig, load_config_from_env
from .schemas import FinalResult

__all__ = [
    "run_claim",
    "AppConfig",
    "load_config_from_env",
    "FinalResult",
]
