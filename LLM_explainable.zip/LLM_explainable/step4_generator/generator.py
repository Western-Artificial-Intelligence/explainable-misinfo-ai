# verifier_pipeline/generator/generator.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
import json

from .mode import choose_mode
from .prompts import build_prompt

@dataclass
class GeneratorOutput:
    mode: str
    content: Dict[str, Any]  # parsed JSON from model

class GeneratorLLM:
    def __init__(self, model_name: str):
        self.model_name = model_name

    def call_llm(self, prompt: str) -> str:
        """
        Replace this with your actual LLM call.
        Must return a JSON string.
        """
        raise NotImplementedError("Implement provider call here")

    def generate(
        self,
        claim: str,
        snippets: List[Dict[str, Any]],
        *,
        verifier_label_id: Optional[int] = None,
        contradiction: bool = False,
    ) -> GeneratorOutput:
        mode = choose_mode(verifier_label_id, contradiction)
        prompt = build_prompt(mode, claim, snippets)
        raw = self.call_llm(prompt)

        # Strict JSON parse (crash fast if model violates schema; you can add a repair step later)
        content = json.loads(raw)
        return GeneratorOutput(mode=mode, content=content)
