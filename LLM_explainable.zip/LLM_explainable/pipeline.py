from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional

from .schemas import EvidenceSnippet, FinalResult, GuardrailResult, GeneratorResult, VerifierResult
from .utils.cache import DiskCache

from .step1_verifier import VerifierPipeline
from .step2_rag import gather_evidence
from .step3_guardrail import evidence_guardrail  # <-- your function name
from .step4_generator import GeneratorLLM


def _normalize_claim(claim: str) -> str:
    return " ".join(str(claim).split()).strip()


def _to_snippets(rag_out: Dict[str, Any]) -> List[EvidenceSnippet]:
    snippets: List[EvidenceSnippet] = []
    for s in rag_out.get("snippets", []):
        text = str(s.get("text") or s.get("snippet") or "")
        snippets.append(
            EvidenceSnippet(
                eid=str(s.get("eid", "")),
                url=str(s.get("url", "")),
                title=str(s.get("title", "")),
                text=text,
                score=float(s.get("score", 0.0)),
            )
        )
    return snippets



def run_claim(
    claim: str,
    *,
    verifier_model_path: str,
    generator_model_name: str,
    cache_dir: str = ".cache/rag",
    use_cache: bool = True,
    rag_kwargs: Optional[Dict[str, Any]] = None,
) -> FinalResult:
    """
    End-to-end verification pipeline:
    0 normalize -> 1 verifier(prior) -> 2 RAG(always) -> 3 guardrail -> 4 generator(optional) -> 5 pack
    """
    rag_kwargs = rag_kwargs or {}
    claim_n = _normalize_claim(claim)

    # 1) Verifier (prior)
    verifier = Verifier(model_path=verifier_model_path)
    v = verifier.predict(claim_n)  # your VerifierOutput dataclass
    verifier_res = VerifierResult(
        label_id=int(v.label_id),
        label=str(v.label),
        conf=float(v.conf),
        score=float(v.score),
        probs=dict(v.probs),
    )

    # 2) RAG (always) with caching
    cache = DiskCache(cache_dir)
    cache_key = cache.key_for_claim(claim_n)

    rag_out: Dict[str, Any]
    if use_cache:
        cached = cache.get_json(cache_key)
        if cached is not None:
            rag_out = cached
        else:
            rag_out = gather_evidence(claim_n, **rag_kwargs)
            cache.set_json(cache_key, rag_out)
    else:
        rag_out = gather_evidence(claim_n, **rag_kwargs)

    evidence = _to_snippets(rag_out)
    urls = sorted({e.url for e in evidence if e.url})

    # 3) Guardrail (evidence sufficiency + contradiction)
    g = evidence_guardrail(claim_n, [asdict(e) for e in evidence])
    
    guard = GuardrailResult(
        status=str(g.status),
        has_contradiction=bool(getattr(g, "has_contradiction", False)),
        used_eids=list(getattr(g, "used_eids", [])),
        metrics=dict(getattr(g, "metrics", {})),
    )

    # If insufficient, we stop BEFORE generator (per your diagram)
    if guard.status != "OK":
        return FinalResult(
            claim=claim_n,
            label_id=verifier_res.label_id,
            label=verifier_res.label,
            conf=verifier_res.conf,
            score=verifier_res.score,
            verdict_status="INSUFFICIENT_EVIDENCE",
            explanation=None,
            correction=None,
            citations=guard.used_eids,
            evidence=evidence,
            urls=urls,
            debug={
                "verifier": asdict(verifier_res),
                "guardrail": asdict(guard),
                "rag_meta": rag_out.get("meta", {}),
            },
        )

    # 4) Generator (explain/correct grounded in evidence)
    gen = GeneratorLLM(model_name=generator_model_name)
    gen_out = gen.generate(
        claim=claim_n,
        snippets=[asdict(e) for e in evidence],
        verifier_label_id=verifier_res.label_id,
    )
    generator_res = GeneratorResult(mode=str(gen_out.mode), content=dict(gen_out.content))

    # 5) Packager (canonical output fields)
    explanation = generator_res.content.get("explanation")
    correction = generator_res.content.get("correction")
    citations = generator_res.content.get("citations") or guard.used_eids

    if isinstance(citations, str):
        citations = [citations]
    citations = [str(c) for c in citations] if citations else []

    return FinalResult(
        claim=claim_n,
        label_id=verifier_res.label_id,
        label=verifier_res.label,
        conf=verifier_res.conf,
        score=verifier_res.score,
        verdict_status="OK",
        explanation=explanation,
        correction=correction,
        citations=citations,
        evidence=evidence,
        urls=urls,
        debug={
            "verifier": asdict(verifier_res),
            "guardrail": asdict(guard),
            "generator": {"mode": generator_res.mode},
            "rag_meta": rag_out.get("meta", {}),
        },
    )
