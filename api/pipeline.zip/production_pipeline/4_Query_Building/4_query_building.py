import json
import asyncio
import hashlib
import os
from typing import List

# Import LLMBlackbox from your llm_blackbox.py
from ..middlewares.llm_blackbox import LLMBlackbox

# ----------------------------
# Env helpers / config
# ----------------------------

# Settings for paraphrase generation
N_VARIANTS = 4  # Generate 4 paraphrases
TEMP_BASE = 0.7  # Temperature for paraphrasing
TOP_P = 0.9  # Top-p for paraphrasing
NUM_PREDICT = 64  # Number of predictions per paraphrase


# ----------------------------
# Paraphrasing with LLM
# ----------------------------

SYS_PARAPHRASE = (
    "/no_think\n"
    "Return ONE paraphrase suitable as a search query.\n"
    "Prefer ONE LINE.\n"
    "Do NOT include reasoning, bullets, numbering, quotes, or multiple options.\n"
    "Preserve entities and names exactly as in the input.\n"
    "Do NOT add suffixes like 'news' or 'fact check'.\n"
)

async def _paraphrase_once(
    claim: str,
    seed: int,
    extra_system: str = "",
    temperature: float = TEMP_BASE
) -> str:
    system = SYS_PARAPHRASE + (("\n" + extra_system.strip()) if extra_system.strip() else "")

    # Using LLMBlackbox to generate paraphrase
    llm = LLMBlackbox()
    paraphrase = await llm.generate(system_context=system, user_context=claim, temperature=temperature)
    return paraphrase


async def _generate_paraphrases(claim: str, claim_id: str, k: int) -> List[str]:
    """
    Generate k paraphrases for a claim using LLM.
    """
    kept_paraphrases = []
    attempt = 0

    while len(kept_paraphrases) < k and attempt < 10:  # limit to 10 attempts
        seed = int(hashlib.sha256(f"{claim_id}:{attempt}".encode("utf-8")).hexdigest()[:8], 16)
        raw_paraphrase = await _paraphrase_once(claim, seed=seed)

        cleaned_paraphrase = raw_paraphrase.strip()
        if cleaned_paraphrase and cleaned_paraphrase not in kept_paraphrases:
            kept_paraphrases.append(cleaned_paraphrase)
        attempt += 1

    return kept_paraphrases


# ----------------------------
# Main function to generate paraphrases and save them to a JSON result
# ----------------------------

async def process_step3_output(claim: str, claim_id: str):
    """
    Main function to process the claim and generate paraphrases.
    """
    print(f"Generating paraphrases for claim: {claim}")
    paraphrases = await _generate_paraphrases(claim, claim_id, k=N_VARIANTS)

    # Prepare the result dictionary
    result = {
        "claim_id": claim_id,
        "original_claim": claim,
        "generated_paraphrases": paraphrases
    }

    # Debugging - print the generated paraphrases and the result JSON
    print(f"Generated {len(paraphrases)} paraphrases:")
    for i, paraphrase in enumerate(paraphrases):
        print(f"Paraphrase {i + 1}: {paraphrase}")

    return result