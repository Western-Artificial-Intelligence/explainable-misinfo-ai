# 4_query_building.py
from __future__ import annotations

import hashlib
import importlib.util
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

# ---- load Ollama blackbox by path (works even with file-loaded steps) ----
_OLLAMA_PATH = Path(__file__).resolve().parents[1] / "middlewares" / "ollama_blackbox.py"
_spec = importlib.util.spec_from_file_location("ollama_blackbox", _OLLAMA_PATH)
assert _spec and _spec.loader
_ollama = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _ollama  # ✅ important
_spec.loader.exec_module(_ollama)

ollama_chat = _ollama.ollama_chat
OllamaBlackboxError = _ollama.OllamaBlackboxError

# ----------------------------
# Constants
# ----------------------------
SYS_PARAPHRASE = (
    "/no_think\n"
    "Output ONE line only.\n"
    "The line must start with PARA: followed immediately by the paraphrase.\n"
    "Do not write anything before PARA:.\n"
    "No reasoning, no quotes, no numbering.\n"
    "Max 12 words. Preserve names/negations exactly.\n"
)

_META_RE = re.compile(
    r"\b(hmm|user wants|we are paraphras|paraphras|rewrite|rephrase|claim|rules|constraints|meaning|max)\b",
    re.IGNORECASE,
)

N_PARAPHRASES = 3
MAX_WORDS = 12
REQUIRE_NUMBERS_MATCH = True

_NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")
_LEADING_JUNK_RE = re.compile(r"^\s*(?:[-*•]\s*|\d+[\)\.\:]\s*|\d+\s+)")
_IS_DEAD_RE = re.compile(r"^(?P<subj>.+?)\s+is\s+dead\s*$", re.IGNORECASE)

# Treat only single-digit list markers, and only if next token is a letter (avoids 2.0 / 3.14)
_ENUM_MARKER_RE = re.compile(r"(?:(?<=\s)|^)[1-9]\s*[\)\.]\s*(?=[A-Za-z])")
_MULTI_ENUM_SPLIT_RE = re.compile(r"\s+[1-9]\s*[\)\.]\s*(?=[A-Za-z])")
_PREFIX_LABEL_RE = re.compile(
    r"^\s*(?:paraphrase|rewrite|rephrase|output|answer)\s*#?\s*\d+\s*(?::|[-–]|\.|\s)\s*",
    re.IGNORECASE,
)
_TRAILING_INDEX_RE = re.compile(r"\s*(?:[\(\[]\s*)?\d{1,3}(?:\s*[\)\]])?\s*$")
_TRAILING_PAREN_WITH_DIGITS_RE = re.compile(r"\s*\([^)]*\d[^)]*\)\s*$")   # "(1/3)", "(12 words)", etc
_TRAILING_SLASH_INDEX_RE = re.compile(r"\s*\d+\s*/\s*\d+\s*$")            # "1/3" without parentheses

_PARA_EXTRACT_RE = re.compile(r"\bpara\s*:\s*(.*)$", re.IGNORECASE)
_PLACEHOLDER_RE = re.compile(
    r"^<\s*paraphrase\s*>$|^\[\s*paraphrase\s*\]$|^paraphrase$|^your paraphrase here$",
    re.IGNORECASE,
)
_PARA_LINE_RE = re.compile(r"^\s*para\s*:\s*(.*)\s*$", re.IGNORECASE)
PARAPHRASE_BACKEND = os.getenv("PARAPHRASE_BACKEND", "heuristic").lower()

class QueryBuildingError(Exception):
    def __init__(self, code: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

def _extract_para(lines: list[str]) -> str:
    for i, ln in enumerate(lines):
        s = ln.strip()

        # strip leading quotes/bullets before checking
        s = s.lstrip("\"'`")
        s = _LEADING_JUNK_RE.sub("", s).strip()

        m = _PARA_LINE_RE.match(s)
        if not m:
            continue

        after = m.group(1).strip()
        if after:
            return after

        # handle:
        # PARA:
        # <text>
        if i + 1 < len(lines):
            return lines[i + 1].strip().lstrip("\"'`")

    return ""

def _copy_meta(meta_in: Dict[str, Any]) -> Dict[str, Any]:
    meta_out: Dict[str, Any] = {"received_at": meta_in["received_at"], "version": meta_in["version"]}
    for k in ("warnings", "latency_ms", "stage_latencies_ms", "total_latency_ms", "stage_errors"):
        if k in meta_in:
            meta_out[k] = meta_in[k]
    return meta_out


def _ensure_warnings(meta: Dict[str, Any]) -> List[Dict[str, str]]:
    w = meta.get("warnings")
    if isinstance(w, list):
        return w
    meta["warnings"] = []
    return meta["warnings"]


def _ensure_stage_latencies(meta: Dict[str, Any]) -> Dict[str, int]:
    v = meta.get("stage_latencies_ms")
    if isinstance(v, dict):
        return v
    meta["stage_latencies_ms"] = {}
    return meta["stage_latencies_ms"]


def _collapse_ws(s: str) -> str:
    return " ".join(s.strip().split())


def _clean_llm(s: str) -> str:
    s = s.strip()
    lines = [ln.strip() for ln in s.splitlines() if ln.strip()]
    para_text = _extract_para(lines)
    if not para_text:
        return ""
    s = para_text

    # ✅ find PARA: on ANY line (and even if line is "PARA:" alone)
    para_text = ""
    for i, ln in enumerate(lines):
        m = _PARA_EXTRACT_RE.search(ln)
        if m is None:
            continue
        after = m.group(1).strip()
        if after:
            para_text = after
        else:
            # handle:
            #   PARA:
            #   <paraphrase>
            if i + 1 < len(lines):
                para_text = lines[i + 1].strip()
        break

    if not para_text:
        return ""

    s = para_text

    # (keep your existing cleaning below)
    s = _PREFIX_LABEL_RE.sub("", s)
    s = _LEADING_JUNK_RE.sub("", s)

    parts = _MULTI_ENUM_SPLIT_RE.split(s, maxsplit=1)
    s = parts[0].strip()

    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        s = s[1:-1].strip()

    s = _TRAILING_PAREN_WITH_DIGITS_RE.sub("", s).strip()
    s = _TRAILING_SLASH_INDEX_RE.sub("", s).strip()
    s = _TRAILING_INDEX_RE.sub("", s).strip()

    s = _collapse_ws(s)

    if _PLACEHOLDER_RE.match(s):
        return ""
    
    if "<" in s or ">" in s:
        return ""

    if _META_RE.search(s):
        return ""

    return s


def _nums(text: str) -> Set[str]:
    text = _ENUM_MARKER_RE.sub("", text)  # remove "2. " / "3) " markers
    return {m.replace(",", "") for m in _NUM_RE.findall(text)}


def _word_count_ok(text: str) -> bool:
    return len(text.split()) <= MAX_WORDS


def _jaccard_overlap(a: str, b: str) -> float:
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


# in 4_query_building.py
async def _paraphrase_once(claim: str, seed: int, *, extra_system: str = "") -> str:
    nums0 = _nums(claim)
    no_digits_rule = ""
    if not nums0:
        no_digits_rule = "The original has NO digits. Output MUST contain NO digits.\n"

    system = no_digits_rule + (SYS_PARAPHRASE if not extra_system else (SYS_PARAPHRASE + " " + extra_system))
    out = await ollama_chat(
        messages=[{"role": "system", "content": system}, {"role": "user", "content": claim}],
        temperature=0.55,
        top_p=0.9,
        seed=seed,
        num_predict=64,
        think=False,   # ✅ now actually works
        stop=["\n"]
    )

    if isinstance(out, dict):
        text = (
            out.get("content")
            or (out.get("message", {}) or {}).get("content")
            or out.get("response")
            or ((out.get("raw", {}) or {}).get("message", {}) or {}).get("content")
            or ""
        )
        # ✅ if model produced no final text, treat as empty (DON'T stringify dict)
        return str(text).strip()

    return str(out).strip() if isinstance(out, str) else ""


async def _paraphrase_with_retry(claim: str, claim_id: str, i: int) -> str:
    seed0 = int(hashlib.sha256(f"{claim_id}:{i}:try0".encode("utf-8")).hexdigest()[:8], 16)
    p0 = _clean_llm(await _paraphrase_once(claim, seed0))
    if p0 and p0 != claim:
        return p0

    seed1 = int(hashlib.sha256(f"{claim_id}:{i}:try1".encode("utf-8")).hexdigest()[:8], 16)
    p1 = _clean_llm(await _paraphrase_once(
        claim, seed1, extra_system="Your last output was too similar. Use different synonyms/rewording."
    ))
    if p1 and p1 != claim:
        return p1

    seed2 = int(hashlib.sha256(f"{claim_id}:{i}:try2".encode("utf-8")).hexdigest()[:8], 16)
    p2 = _clean_llm(await _paraphrase_once(
        claim, seed2, extra_system="You MUST change wording. If stuck, use synonyms like 'has died'/'died'/'is deceased'."
    ))
    return p2


def _heuristic_fallback_variants(claim: str) -> List[str]:
    c = _collapse_ws(claim)
    m = _IS_DEAD_RE.match(c)
    if m:
        subj = m.group("subj").strip()
        return [f"{subj} has died", f"{subj} died", f"{subj} is deceased"]
    return [f"{c} news", f"fact check {c}"]


async def process_step3_output(step3_out: Dict[str, Any]) -> Dict[str, Any]:
    try:
        request_id = step3_out["request_id"]
        claim_id = step3_out["claim_id"]
        user_claim = step3_out["user_claim"]
        normalized_claim = step3_out["normalized_claim"]
        roberta = step3_out["roberta"]
        routing = step3_out["routing"]
        meta_in = step3_out["meta"]

        enabled = bool(routing["rag"]["use_query_expansion"])
    except Exception as e:
        raise QueryBuildingError("INVALID_INPUT", "Step4 expected Step3 output shape.", {"error": str(e)})

    t0 = time.perf_counter()
    meta_out = _copy_meta(meta_in)
    warnings = _ensure_warnings(meta_out)
    stage_lat = _ensure_stage_latencies(meta_out)

    queries: List[Dict[str, str]] = [{"q": normalized_claim, "variant": "original"}]
    kept = 0
    mode = "original_only"

    drop_counts = {"empty": 0, "same": 0, "dup": 0, "nums": 0, "too_long": 0, "too_similar": 0}

    if enabled:
        raw: List[str] = []
        if PARAPHRASE_BACKEND in ("llm", "auto"):
            try:
                for i in range(N_PARAPHRASES):
                    raw.append(await _paraphrase_with_retry(normalized_claim, claim_id, i))
            except OllamaBlackboxError as e:
                warnings.append({"code": "PARAPHRASE_LLM_FAILED", "message": f"LLM paraphrase failed: {e.code}"})
                raw = []

        nums0 = _nums(normalized_claim)
        kept_paras: List[str] = []

        for p in raw:
            p = _collapse_ws(p)
            if not p:
                drop_counts["empty"] += 1
                continue
            if p == normalized_claim:
                drop_counts["same"] += 1
                continue
            if p in kept_paras:
                drop_counts["dup"] += 1
                continue
            print("P_RAW:", repr(p))
            print("P_NUMS:", _nums(p), "NUMS0:", nums0)
            if REQUIRE_NUMBERS_MATCH and _nums(p) != nums0:
                drop_counts["nums"] += 1
                continue
            if not _word_count_ok(p):
                drop_counts["too_long"] += 1
                continue
            # avoid near-copies (cheap heuristic)
            if _jaccard_overlap(p, normalized_claim) > 0.85:
                drop_counts["too_similar"] += 1
                continue

            kept_paras.append(p)
            if len(kept_paras) == N_PARAPHRASES:
                break

        if len(kept_paras) == 0:
            fb = _heuristic_fallback_variants(normalized_claim)
            for p in fb:
                p = _collapse_ws(p)
                if not p or p == normalized_claim or p in kept_paras:
                    continue
                if REQUIRE_NUMBERS_MATCH and _nums(p) != nums0:
                    continue
                if not _word_count_ok(p):
                    continue
                kept_paras.append(p)
                if len(kept_paras) == N_PARAPHRASES:
                    break

            if len(kept_paras) > 0:
                warnings.append({"code": "PARAPHRASE_HEURISTIC_FALLBACK", "message": "Used heuristic fallback paraphrases."})
            else:
                warnings.append({"code": "PARAPHRASE_NONE_KEPT", "message": "No paraphrases passed filters."})

        for p in kept_paras:
            queries.append({"q": p, "variant": "paraphrase"})

        kept = len(kept_paras)
        mode = "original_plus_paraphrases" if kept > 0 else "original_only"

        # optional: emit a warning if we dropped lots due to number mismatch
        if drop_counts["nums"] > 0:
            warnings.append({"code": "PARAPHRASE_DROPPED_NUM_MISMATCH", "message": "Dropped paraphrases due to number mismatch."})

    dt_ms = int(round((time.perf_counter() - t0) * 1000))
    stage_lat["step4_query_building"] = max(0, dt_ms)

    query_plan = {
        "mode": mode,
        "primary_query": normalized_claim,
        "queries": queries,  # 1..4
        "paraphrase_meta": {
            "enabled": enabled,
            "n_requested": (N_PARAPHRASES if enabled else 0),
            "kept": kept,
            "filter": {"require_numbers_match": REQUIRE_NUMBERS_MATCH, "max_words": MAX_WORDS},
            "dropped": drop_counts,  # remove if schema disallows extra keys
        },
    }

    return {
        "request_id": request_id,
        "claim_id": claim_id,
        "user_claim": user_claim,
        "normalized_claim": normalized_claim,
        "roberta": roberta,
        "routing": routing,
        "query_plan": query_plan,
        "meta": meta_out,
    }